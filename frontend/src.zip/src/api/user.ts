import { request } from '@/utils/request'
import axios from 'axios'
import { BACKEND_URL } from '@/config'



export function login(params?: any) {
  return axios.get(BACKEND_URL+'/user/login', { params })
}


export function panel(params?: any) {
  return axios.get(BACKEND_URL+'/user/panel', { params })
}


export function historyOther(params?: any) {
  return axios.get(BACKEND_URL+'/user/my_history_other', { params })
}

export function friends(params?: any) {
  return axios.get(BACKEND_URL+'/user/friends', { params })
}

export function userinfo(params?: any) {
  return axios.get(BACKEND_URL+'/user/userinfo', { params })
}


// -------------------------------------original--------------------------------------- //

// export function userinfo(params?: any, data?: any) {
//   return request({ url: '/user/userinfo', method: 'get', params, data })
// }




