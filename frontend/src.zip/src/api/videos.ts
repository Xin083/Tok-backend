import { BACKEND_URL } from '@/config'
import axios from 'axios'


export function myVideo(params?: any) {
  return axios.get(BACKEND_URL+'/user/my_video', { params });
}

export function privateVideo(params?: any) {
  return axios.get(BACKEND_URL+'/user/my_private', { params });
}

export function likeVideo(params?: any) {
  return axios.get(BACKEND_URL+'/user/my_like_video', { params });
}

export function collectVideo(params?: any) {
  return axios.get(BACKEND_URL+'/user/my_collect_video', { params })
}

export function recommendedVideo(params?: any) {
  return axios.get(BACKEND_URL+'/video/recommended', { params })
}

export function recommendedLongVideo(params?: any) {
  return axios.get(BACKEND_URL+'/video/long_recommended', { params })
}

export function historyVideo(params?: any) {
  return axios.get(BACKEND_URL+'/user/my_history_video', { params })
}

export function videoComments(params?: any) {
  return axios.get(BACKEND_URL+'/video/comments', { params })
}

export function userVideoList(params?: any) {
  return axios.get(BACKEND_URL+'/user/video_list', { params })
}

export function videoDigg(params?: any) {
  return axios.post(BACKEND_URL + '/video/digg', params )
}

