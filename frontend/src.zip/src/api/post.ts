import axios from 'axios'
import { BACKEND_URL } from '@/config'

export function recommendedPost(params?: any) {
  return axios.get(BACKEND_URL+'/post/recommended', { params })
}