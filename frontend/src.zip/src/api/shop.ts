import axios from 'axios'
import { BACKEND_URL } from '@/config'

export function recommendedShop(params?: any) {
  return axios.get(BACKEND_URL+'/shop/recommended', { params })
}
